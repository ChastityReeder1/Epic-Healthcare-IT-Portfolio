CREATE DATABASE Epic_Data_Audit;
GO

USE Epic_Data_Audit;
GO


-- Create Patients table
CREATE TABLE Patients (
    PatientID VARCHAR(10),
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DOB DATE,
    MRN VARCHAR(10),
    ActiveFlag VARCHAR(5)
);

-- Insert sample data (some clean, some dirty)
INSERT INTO Patients VALUES
('P001', 'Tammy', 'Lamb', '1985-01-15', '10001', 'Y'),
('P002', 'Marcus', 'Reed', '1990-07-22', '10002', 'Y'),
('P003', 'Lisa', 'Turner', NULL, '10003', 'Y'),          -- Missing DOB
('P004', 'James', 'Hall', '1978-03-09', '10002', 'Y'),   -- Duplicate MRN
('P005', 'Brandi', 'Cole', '1992-11-30', '10005', 'N'),
('P006', 'Robert', 'Miles', '1981-09-18', '10006', 'Yes'), -- Invalid flag
('P007', 'Rachel', 'Kim', '1988-05-12', '10007', 'Y'),
('P008', 'Ethan', 'Wells', '1991-06-22', '10008', 'Y'),
('P009', 'Jasmine', 'Brooks', '1975-04-18', '10009', 'Y'),
('P010', 'Laura', 'Mason', '1993-10-05', '10010', 'N'),
('P011', 'Travis', 'Parker', NULL, '10011', 'Y'),        -- Missing DOB
('P012', 'Kendra', 'Stone', '1989-12-02', '10012', 'y'), -- Lowercase flag
('P013', 'Aaron', 'King', '1977-09-14', '10013', 'Y'),
('P014', 'Crystal', 'James', '1990-02-23', '10014', 'N'),
('P015', 'Naomi', 'Foster', '1995-07-29', '10015', 'Yes'), -- Invalid flag
('P016', 'Eric', 'Davis', '1982-03-31', '10016', NULL),  -- Missing ActiveFlag
('P017', 'Megan', 'Price', '1988-11-04', '10017', 'Y'),
('P018', 'Shawn', 'Lee', '1991-01-10', '10018', 'Y'),
('P019', 'Patricia', 'White', '1979-08-25', '10019', 'N'),
('P020', 'James', 'Hall', '1978-03-09', '10020', 'Y');   -- Duplicate name


SELECT * FROM Patients;



-- Create Encounters table
CREATE TABLE Encounters (
    EncounterID VARCHAR(10),
    PatientID VARCHAR(10),
    VisitDate DATE,
    Department VARCHAR(50),
    Provider VARCHAR(50),
    DiagnosisCode VARCHAR(10)
);

-- Insert sample data (20 records with data issues)
INSERT INTO Encounters VALUES
('E001', 'P001', '2024-01-15', 'Cardiology', 'Dr. Patel', 'I10'),
('E002', 'P002', '2024-02-02', 'Dermatology', 'Dr. King', 'L30'),
('E003', 'P003', '2024-03-12', 'Primary Care', 'Dr. Wong', 'E11'),
('E004', 'P004', '2024-03-15', 'Orthopedics', 'Dr. Hall', 'M17'),
('E005', 'P005', '2024-03-19', 'Neurology', 'Dr. Kim', 'G40'),
('E006', 'P005', '2024-04-10', 'Neurology', 'Dr. Kim', 'G40'),    -- duplicate encounter
('E007', 'P006', '2024-04-25', 'Cardiology', 'Dr. Patel', 'I20'),
('E008', 'P008', '2024-04-30', 'Primary Care', 'Dr. Wong', 'E78'),
('E009', 'P009', '2024-05-01', 'Endocrinology', 'Dr. Lewis', 'E11'),
('E010', 'P011', '2024-05-05', 'Primary Care', 'Dr. King', 'E11'),
('E011', 'P012', '2024-05-12', 'Cardiology', 'Dr. Patel', NULL),  -- missing diagnosis
('E012', 'P013', NULL, 'Dermatology', 'Dr. King', 'L40'),         -- missing visit date
('E013', 'P014', '2024-06-05', 'Oncology', 'Dr. Smith', 'C50'),
('E014', 'P015', '2024-06-10', 'Radiology', 'Dr. Carter', 'Z01'),
('E015', 'P017', '2024-06-18', 'Primary Care', 'Dr. Patel', 'E11'),
('E016', 'P018', '2024-06-22', 'Cardiology', 'Dr. Lewis', 'I50'),
('E017', 'P021', '2024-06-25', 'Orthopedics', 'Dr. Hall', 'M25'), -- invalid PatientID (no P021)
('E018', 'P016', '2024-07-01', 'Neurology', NULL, 'G43'),        -- missing provider
('E019', 'P019', '2024-07-03', 'Oncology', 'Dr. Smith', 'C18'),
('E020', 'P020', '2024-07-05', 'Primary Care', 'Dr. Wong', 'Z00');



-- Create Insurance table
CREATE TABLE Insurance (
    InsuranceID VARCHAR(10),
    PatientID VARCHAR(10),
    PayerName VARCHAR(50),
    PolicyNumber VARCHAR(20),
    CoverageStart DATE,
    CoverageEnd DATE
);

INSERT INTO Insurance VALUES
('I001', 'P001', 'Aetna', 'AE12345', '2023-01-01', '2023-12-31'),
('I002', 'P002', 'Blue Cross', 'BC54321', '2023-01-01', '2023-12-31'),
('I003', 'P003', 'Cigna', 'CG99999', '2023-02-01', NULL),               -- missing end date
('I004', 'P004', 'Blue Cross', 'BC11111', '2023-03-01', '2023-12-31'),
('I005', 'P005', 'Aetna', NULL, '2023-04-01', '2023-12-31'),           -- missing policy number
('I006', 'P006', 'Aetna', 'AE00001', '2023-05-01', '2023-12-31'),
('I007', 'P007', 'Blue Cross', 'BC00002', '2023-06-01', '2023-12-31'),
('I008', 'P008', 'Cigna', 'CG00003', '2023-06-01', '2023-12-31'),
('I009', 'P009', 'Aetna', 'AE00004', '2023-07-01', '2023-12-31'),
('I010', 'P010', 'Aetna', 'AE00005', NULL, NULL),                      -- missing coverage dates
('I011', 'P011', 'Blue Cross', 'BC00006', '2023-07-01', '2023-12-31'),
('I012', 'P012', 'Cigna', 'CG00007', '2023-08-01', '2023-12-31'),
('I013', 'P013', 'Aetna', 'AE00008', '2023-09-01', '2023-12-31'),
('I014', 'P014', 'Blue Cross', 'BC00009', '2023-09-01', '2023-12-31'),
('I015', 'P015', 'Cigna', 'CG00010', '2023-10-01', '2023-12-31'),
('I016', 'P016', 'Cigna', 'CG00011', '2023-10-01', '2023-12-31'),
('I017', 'P018', 'Aetna', 'AE00012', '2023-11-01', '2023-12-31'),
('I018', 'P019', 'Aetna', 'AE00013', '2023-11-01', '2023-12-31'),
('I019', 'P021', 'Cigna', 'CG00014', '2023-11-01', '2023-12-31'),      -- invalid PatientID
('I020', 'P020', 'Blue Cross', 'BC00015', '2023-11-15', '2023-12-31');




SELECT COUNT(*) AS Patients FROM Patients;
SELECT COUNT(*) AS Encounters FROM Encounters;
SELECT COUNT(*) AS Insurance FROM Insurance;

SELECT *  FROM Patients;
SELECT *  FROM Encounters;
SELECT *  FROM Insurance;


--Finding Missing DOB

SELECT PatientID, FirstName, LastName, MRN, DOB
FROM Patients
WHERE DOB IS NULL;

--Finding Duplicate MRNs

SELECT MRN, COUNT(*) AS MRN_Count
FROM Patients
GROUP BY MRN
HAVING COUNT(*) > 1;

--Finding Invalid Active Flags

SELECT PatientID, FirstName, LastName, ActiveFlag
FROM Patients
WHERE ActiveFlag NOT IN ('Y', 'N')
   OR ActiveFlag IS NULL;





--Looking up bad Encounter Data

--Check for Encounters with missing VisitDate

SELECT EncounterID, PatientID, VisitDate, Department, Provider
FROM Encounters
WHERE VisitDate IS NULL;


--Check for Encounters with Missing Providers

SELECT EncounterID, PatientID, VisitDate, Department, Provider
FROM Encounters
WHERE Provider IS NULL;


--Check for Encounters where Paitent ID does not exist in Paitent

SELECT e.EncounterID, e.PatientID, e.VisitDate, e.Department
FROM Encounters e
LEFT JOIN Patients p
    ON e.PatientID = p.PatientID
WHERE p.PatientID IS NULL;



--Missing Policy Numbers

-- Insurance records missing policy number
SELECT InsuranceID, PatientID, PayerName, PolicyNumber
FROM Insurance
WHERE PolicyNumber IS NULL
   OR LTRIM(RTRIM(PolicyNumber)) = '';



 -- Insurance records missing coverage start or end dates
SELECT InsuranceID, PatientID, PayerName, PolicyNumber,
       CoverageStart, CoverageEnd
FROM Insurance
WHERE CoverageStart IS NULL
   OR CoverageEnd IS NULL;


 -- Insurance records linked to invalid PatientIDs
SELECT i.InsuranceID, i.PatientID, i.PayerName, i.PolicyNumber
FROM Insurance i
LEFT JOIN Patients p
    ON i.PatientID = p.PatientID
WHERE p.PatientID IS NULL;




--Cross-Table Integrity Checks

-- Patients that exist in registration but have never had an encounter
SELECT p.PatientID, p.FirstName, p.LastName, p.MRN
FROM Patients p
LEFT JOIN Encounters e
    ON p.PatientID = e.PatientID
WHERE e.PatientID IS NULL;


-- Patients with no insurance record on file
SELECT p.PatientID, p.FirstName, p.LastName, p.MRN
FROM Patients p
LEFT JOIN Insurance i
    ON p.PatientID = i.PatientID
WHERE i.PatientID IS NULL;


-- Patients who had an encounter but are missing insurance coverage
SELECT DISTINCT e.PatientID, p.FirstName, p.LastName, e.EncounterID, e.VisitDate
FROM Encounters e
LEFT JOIN Patients p
    ON e.PatientID = p.PatientID
LEFT JOIN Insurance i
    ON e.PatientID = i.PatientID
WHERE i.PatientID IS NULL;
